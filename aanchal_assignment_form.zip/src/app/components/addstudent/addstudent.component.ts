import { Component, OnInit } from '@angular/core';
import {FormGroup, FormControl} from '@angular/forms';
import {StudentsService} from '../../students.service';


@Component({
  selector: 'app-addstudent',
  templateUrl: './addstudent.component.html',
  styleUrls: ['./addstudent.component.css']
})
export class AddstudentComponent implements OnInit {
constructor(private student:StudentsService){}
addStudent=new FormGroup({
name: new FormControl(''),
email:new FormControl(''),
department:new FormControl(''),
subject1:new FormControl(''),
subject2:new FormControl(''),
subject3:new FormControl(''),
subject4:new FormControl(''),
subject5:new FormControl(''),
  }
  );
  message:boolean=false;
ngOnInit(): void {

}
SaveData(){
  //console.log(this.addStudent.value);
  this.student.saveStudentData(this.addStudent.value).subscribe((result)=>{
    //console.log(result);
    this.message=true;
    this.addStudent.reset({});
  });
}
removeMessage(){
  this.message=false;
}
}
